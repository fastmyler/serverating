# ServeRating - Web Hosting Reviews website. 

# WP Based. GPL THEME -> Zinc – Free Bootstrap 5 HTML5 Business Website Template (https://themewagon.com/themes/free-bootstrap-5-html5-business-website-template-zinc/)

# Main 2 components 
# Serverating Custom Theme 
# Custom Plugin wpreview

# The Theme includes all the required files like single.php, header.php, page.php, archive.php and etc to provide a fully functional them with decent styling. The Theme also includes custom post type templates like single-review_item and more 

# The Plugin Includes lot of functions like the cpt-review which is the main function that will create the custom post type. Also the Plugin provides functionality to give star rating review as a WP Coment, which saves the ratings as wpmeta and also calculates the average rating for the comment. The plugin also comes with the functionality to count the average company rating based on the average of the 4 criteries and all the comments . The plugin also allows comes with additional meta informatio which is filled from the ADMIN dashboard like affiliate URL, Expert Score for the provider, Sort Order (Which us used in the listings of the companies) and more. 

